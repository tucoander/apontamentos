-- SQLite
INSERT into usraut (usr_id, usrrol) VALUES ('FAA5LOV','ADM');
INSERT into usraut (usr_id, usrrol) VALUES ('DOM9ITV','USR');
INSERT into usraut (usr_id, usrrol) VALUES ('LOD9LOV','ADM');
INSERT into usraut (usr_id, usrrol) VALUES ('BOM5ITV','USR');
INSERT into usraut (usr_id, usrrol) VALUES ('BAF8LOV','USR');

