
    <?php
        include('./template-barra.php');
    ?>
    <link href="mdtimepicker.css" rel="stylesheet">

    <main role="main" class="container-fluid">
        <div class="card">
            <div class="card-body">
                Escolha uma opção no menu superior
            </div>
        </div>
    </main>
    <?php
        include('./template-rodape.php');
    ?>
    


