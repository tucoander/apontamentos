    <nav class="navbar navbar-bosch bg-bosch fixed-bottom" style="height:15px;">
        <a class="navbar-brand" >
           <br>
        </a>
    </nav>
    <!-- JavaScript (Opcional) -->
    <!-- jQuery primeiro, depois Popper.js, depois Bootstrap JS -->
    <script src="../../jquery/jquery-3.3.1.min.js"></script>
    <script src="../../popper/popper.min.js"></script>
    <script src="../../bootstrap/js/bootstrap.js"></script>
    <script src="../../mdt/js/mdtimepicker.js"></script>
    <script src="../../bootstable/js/bootstable.min.js"></script>
    <script src="../../dashboard/js/Chart.js"></script>
    </body>
</html>
