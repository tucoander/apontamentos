<?php
    print  $_POST['exampleInputEmail1'];
    print '<br>';
    print  $_POST['exampleInputPassword1'];
?>